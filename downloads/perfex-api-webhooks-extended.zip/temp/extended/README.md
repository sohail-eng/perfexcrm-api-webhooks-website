# PerfexCRM API & Webhooks Module - Extended License

Welcome to the PerfexCRM API & Webhooks Module!

## Installation

1. Upload the module files to your PerfexCRM installation
2. Activate the module in Admin > Modules
3. Configure your API settings
4. Set up webhooks as needed

## Documentation

Full documentation is available at: https://perfexapi.com/docs

## Support

Priority support is included with extended license.

## License

This is licensed under the Extended License.

## Features

- RESTful API endpoints
- Webhook notifications
- Authentication system
- Rate limiting
- Request logging
- Advanced webhook features
- Unlimited domain usage
- Priority support
- Custom integrations

Version 1.0.0
